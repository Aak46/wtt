<?php
include("config.php");
$id = $_GET['id'];
$result = mysqli_query($mysqli, "DELETE FROM users WHERE id=$id");
header("Location:index.php");
?>
6. config.php
<?php
$database = 'localhost';
Page 57Web Technology Lab Manual
$dbName = 'test';
$dbUser = 'root';
$dbPass = '';
$mysqli = mysqli_connect($database, $dbUser, $dbPass, $dbName);
?>
7. database.sql
a. create database emp;
b. use emp;
c. CREATE TABLE `users` (
`id` int(11) NOT NULL auto_increment,
`name` varchar(100) NOT NULL,
`age` int(3) NOT NULL,
`email` varchar(100) NOT NULL,
PRIMARY KEY (`id`)
);
